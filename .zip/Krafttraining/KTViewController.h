//
//  KTViewController.h
//  Krafttraining
//
//  Created by Benedikt on 22/03/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface KTViewController : UIViewController {

}

@end
